import React from 'react';
import Header from '../../component/Header/Header';

const LandingPage = () => {
  return (
    <div>
      <Header />
    </div>
  );
};

export default LandingPage;
